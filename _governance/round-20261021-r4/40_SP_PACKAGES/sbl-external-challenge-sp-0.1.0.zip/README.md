# sbl-external-challenge-sp

Portable Agent Plugin package for the SBL specialised principal `external_challenge_sp` (independent-challenger).

- portable manifest: `plugin.json` (`https://agent-plugins.org/schemas/1.0.0/plugin.schema.json`)
- skill: `skills/external-challenge-sp/SKILL.md`
- claim ceiling: `HOST_PENDING` (a package is not an installation)
- permissions: evidence.read, challenge.sign
- forbidden: product.write, goal.write

Importing this package into a host is a separate, human, host-side action. Do not report
`INSTALLED` on the strength of the ZIP existing.

# sbl-tpm-sp

Portable Agent Plugin package for the SBL specialised principal `tpm_sp` (product-manager).

- portable manifest: `plugin.json` (`https://agent-plugins.org/schemas/1.0.0/plugin.schema.json`)
- skill: `skills/tpm-sp/SKILL.md`
- claim ceiling: `HOST_PENDING` (a package is not an installation)
- permissions: goal.read, spec.write, evidence.read
- forbidden: product.write, challenge.sign

Importing this package into a host is a separate, human, host-side action. Do not report
`INSTALLED` on the strength of the ZIP existing.

# sbl-commander-sp

Portable Agent Plugin package for the SBL specialised principal `commander_sp` (build-commander).

- portable manifest: `plugin.json` (`https://agent-plugins.org/schemas/1.0.0/plugin.schema.json`)
- skill: `skills/commander-sp/SKILL.md`
- claim ceiling: `HOST_PENDING` (a package is not an installation)
- permissions: product.write, build.route, evidence.read
- forbidden: challenge.sign, verdict.sign

Importing this package into a host is a separate, human, host-side action. Do not report
`INSTALLED` on the strength of the ZIP existing.
